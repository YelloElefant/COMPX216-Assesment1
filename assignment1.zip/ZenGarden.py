# Zen garden simulation

from time import time
from assignment1 import *



